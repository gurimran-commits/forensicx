"""ForensicX application package."""
