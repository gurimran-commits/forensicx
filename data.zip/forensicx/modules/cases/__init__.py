"""Case management module."""
