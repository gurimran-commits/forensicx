"""Dashboard feature module."""
